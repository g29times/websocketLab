/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.ease.listener.ProgressListener;
import com.aliyun.oas.ease.transfer.Transfer;
import com.aliyun.oas.model.common.Range;
import com.aliyun.oas.model.common.ServiceCredentials;
import com.aliyun.oas.model.result.UploadResult;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: UploadWithListeners.java, v 0.1 2015-6-3 下午3:10:29 jialan Exp $
 */
public class UploadWithListeners {
    //Create the logger
    private static final Logger logger = LoggerFactory.getLogger(UploadWithListeners.class);

    public static void main(String[] args) {
        ServiceCredentials credentials = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "http://cn-hangzhou.oas.aliyuncs.com");
        File file120MB = new File("oas_demo_data/random10M.bin");

        archiveManager.withMaxRetryTimePerRequest(3);
        final Transfer<UploadResult> bt = archiveManager.uploadAsync("oas_demo", file120MB);

        //设置最大并发数，默认为3，最大为10
        bt.setNumConcurrence(5);

        bt.addProgressListener(new ProgressListener() {

            @Override
            public void onStart(String id) {
                // 任务开始时调用，其中id为Multipart Upload任务ID，对于一般上传任务id为空
                System.out.println("Start! Upload ID: " + id);
            }

            @Override
            public boolean onError(Range range, Throwable t) {
                // 出错时调用，range是出错的字节范围，t是相应的错误
                // 当返回true时，TransferManager会进行重试，false则放弃
                System.out.println("ERROR!!!");
                return false;
            }

            @Override
            public void onCompleted() {
                // 任务完成时调用
                System.out.println("Upload complete");
            }

            @Override
            public void onProgressed(long current, long total) {
                // 上传进度，total为文件字节大小，current为当前已上传字节数
                System.out.println("Progress: " + current + " / " + total);
            }
        });

        bt.start();

        final Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                System.out.println("Running time: " + bt.getRunningTime() + " seconds");
                System.out.println("Completed size: " + bt.getCompletedSize() + " bytes");
                System.out.println("Total size: " + bt.getTotalSize() + " bytes");
                System.out.println("Average speed: " + bt.getAverageSpeedInBytesPerSecond()
                                   + " B/s");
                if (bt.isComplete()) {
                    timer.cancel();
                    synchronized (bt) {
                        bt.notify();
                    }
                }
            }

        }, 0, 1000);

        synchronized (bt) {
            try {
                bt.wait();
            } catch (InterruptedException e) {
                logger.error("", e);
            }
        }

        System.out.println("=============================");
        System.out.println("Running time: " + bt.getRunningTime() + " seconds");
        System.out.println("Completed size: " + bt.getCompletedSize() + " bytes");
        System.out.println("Total size: " + bt.getTotalSize() + " bytes");
        System.out.println("Average speed: " + bt.getAverageSpeedInBytesPerSecond() + " B/s");
        UploadResult uploadResult = bt.getResult();
        System.out.println("Archive ID: " + uploadResult.getArchiveId());
        System.out.println("ContentEtag: " + uploadResult.getContentEtag());

    }
}
