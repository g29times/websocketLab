/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.io.File;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.model.common.ServiceCredentials;
import com.aliyun.oas.model.result.UploadResult;

/**
 * 本Demo中的上传使用的是 ArchiveManager.initiateMultipartUpload 和 ArchiveManager.uploadWithUploadId 接口，
 * @author jialan@alibaba-inc.com
 * @version $Id: MultipartUploadWithUploadId.java, v 0.1 2015-5-25 下午4:29:38 jialan Exp $
 */
public class MultipartUploadWithUploadId {
    public static void main(String[] args) {
        String vaultName = TestConstants.VAULT_NAME;
        //初始化archiveManager
        ServiceCredentials credentials = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "http://cn-hangzhou.oas.aliyuncs.com");

        File file = new File("oas_demo_data/random120M.bin");
        //获得uploadId
        //文件大小必须大于100MB，否则会抛异常提示用普通上传接口进行上传
        String uploadId = archiveManager.initiateMultipartUpload(vaultName, file, "Hello OAS!");
        //如果是已有的uploadId，直接使用之前获取过的uploadId
        //String uploadId = "507B33C542264BD8B41503C33F516FE5";
        System.out.println("Get uploadId=" + uploadId);
        UploadResult uploadResult = archiveManager.uploadWithUploadId(vaultName, file, uploadId);
        System.out.println("Archive ID=" + uploadResult.getArchiveId());
    }
}
