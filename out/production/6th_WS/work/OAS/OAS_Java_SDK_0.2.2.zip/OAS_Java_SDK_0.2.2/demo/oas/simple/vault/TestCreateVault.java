/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.simple.vault;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.core.AliyunOASClient;
import com.aliyun.oas.model.common.ClientConfiguration;
import com.aliyun.oas.model.common.ServiceCredentials;
import com.aliyun.oas.model.common.ServiceHost;
import com.aliyun.oas.model.exception.OASClientException;
import com.aliyun.oas.model.exception.OASServerException;
import com.aliyun.oas.model.request.CreateVaultRequest;
import com.aliyun.oas.model.result.CreateVaultResult;

/**
 * 创建vault demo程序
 * 每个用户最多创建10个vault
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: TestCreateVault.java, v 0.1 2015-5-12 上午11:18:20 jialan Exp $
 */
public class TestCreateVault {
    //Create the logger
    private static final Logger logger = LoggerFactory.getLogger(TestCreateVault.class);

    public static void main(String[] args) {
        String yourAccessKeyId = TestConstants.ACCESS_ID;
        String yourAccessKeySecret = TestConstants.ACCESS_KEY;

        //初始化认证信息
        ServiceCredentials credentials = new ServiceCredentials(yourAccessKeyId,
            yourAccessKeySecret);
        //服务地址
        ServiceHost serviceHost = new ServiceHost("http://cn-hangzhou.oas.aliyuncs.com", 80);
        //客户端配置
        ClientConfiguration clientConfiguration = new ClientConfiguration();
        // 方法1
        AliyunOASClient aliyunOASClient = OASFactory
            .aliyunOASClientFactory(serviceHost, credentials, clientConfiguration).withLogger();
            // 方法2
            //        AliyunOASClient aliyunOASClient2 = OASFactory.aliyunOASClientFactory(credentials,
            //            "http://cn-hangzhou.oas.aliyuncs.com");

        //        AliyunOASClient aliyunOASClient2 = OASFactory.getEmptyAliyunOASClient().withLogger();
        //        aliyunOASClient2
        //            .withServiceCredentials(new ServiceCredentials(yourAccessId, yourAccessKey));
        //
        //        aliyunOASClient2.withHost("http://cn-hangzhou.oas.aliyuncs.com/");

        // 或者像下面这样，通过url创建AliyunOASClient对象
        //        AliyunOASClient aliyunOASClient = OASFactory.aliyunOASClientFactory(credentials,
        //            "http://cn-hangzhou.oas.aliyuncs.com").withLogger();

        // vaultName必须满足已下2个条件：
        // 1. 总长度在3~63之间（包括3和63）；
        // vaultName必须满足已下2个条件：
        // 1. 总长度在3~63之间（包括3和63）；
        // 2. 只允许包含以下字符：
        //         0-9(数字),
        //         a-z(小写英文字母),
        //         -(短横线),
        //         _(下划线)
        // 其中 短横线 和 下划线 不能作为vaultName的开头和结尾；
        String vaultName = "oas_demo";

        // 发送创建vault请求
        // 创建Vault的名称，用CreateVaultRequest来指定
        CreateVaultRequest createRequest = new CreateVaultRequest().withVaultName(vaultName);

        // 发起创建Vault的请求
        // 如果有同名的vault存在，OAS会返回已有的vault的vaultId，而不会执行创建动作
        try {
            CreateVaultResult result = aliyunOASClient.createVault(createRequest);
            logger.info("Vault created vaultId={}", result.getVaultId());
            logger.info("Vault created vaultLocation={}", result.getLocation());
        } catch (OASClientException e) {
            logger.error("OASClientException Occured:", e);
        } catch (OASServerException e) {
            logger.error("OASServerException Occured:", e);
        }

        System.out.println("ddddddddddddddddd");

    }
}
