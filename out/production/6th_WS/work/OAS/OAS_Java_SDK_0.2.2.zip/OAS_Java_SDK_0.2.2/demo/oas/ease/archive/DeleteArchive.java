/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.model.common.ServiceCredentials;
import com.aliyun.oas.model.result.OASResult;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: DeleteArchive.java, v 0.1 2015-6-16 下午3:11:20 jialan Exp $
 */
public class DeleteArchive {
    public static void main(String[] args) {

        ServiceCredentials credentials = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        String host = "http://cn-hangzhou.oas.aliyuncs.com";
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials, host);

        String archiveId = "";
        String vaultName = "oas_demo";

        OASResult result = archiveManager.deleteArchive(vaultName, archiveId);
        System.out.println(result);

    }
}
