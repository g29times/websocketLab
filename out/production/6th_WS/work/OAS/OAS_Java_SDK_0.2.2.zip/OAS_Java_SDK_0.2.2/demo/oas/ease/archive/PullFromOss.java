/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.util.Timer;
import java.util.TimerTask;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.ease.monitor.JobMonitor;
import com.aliyun.oas.model.common.ServiceCredentials;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: PullFromOss.java, v 0.1 2015年9月17日 下午2:04:56 jialan Exp $
 */
public class PullFromOss {
    public static void main(String[] args) {
        String yourAccessKeyId = TestConstants.ACCESS_ID;
        String yourAccessKeySecret = TestConstants.ACCESS_KEY;
        //初始化认证
        ServiceCredentials credentials = new ServiceCredentials(yourAccessKeyId,
            yourAccessKeySecret);
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "10.101.200.206");

        final JobMonitor jobMonitor = archiveManager.pullFromOssAsync("test",
            "oss-test.aliyun-inc.com", "oastest", "smallfile", "jialan test");

        final Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                if (jobMonitor.checkJobFinishedWithRefresh()) {
                    timer.cancel();
                    synchronized (jobMonitor) {
                        jobMonitor.notify();
                    }
                }
                //System.out.println("Job's current status:" + jobMonitor.getJobStatus());
            }
        }, 0, 5000);

        synchronized (jobMonitor) {
            try {
                jobMonitor.wait();
            } catch (InterruptedException e) {
            }
        }
        System.out.println("Job has ended.");
        System.out
            .println("JobId=" + jobMonitor.getJobId() + ", JobStatus=" + jobMonitor.getJobStatus()
                     + ", archiveId=" + jobMonitor.getDescriptor().getArchiveId()
                     + ", archiveTreeEtag=" + jobMonitor.getDescriptor().getArchiveTreeEtag());
    }
}
