/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.model.common.ServiceCredentials;
import com.aliyun.oas.model.exception.OASClientException;
import com.aliyun.oas.model.exception.OASServerException;
import com.aliyun.oas.model.result.UploadResult;

/**
 * 本Demo中的上传使用的是 ArchiveManager.upload 接口，
 * @author jialan@alibaba-inc.com
 * @version $Id: TestArchive.java, v 0.1 2015-5-12 下午2:56:17 jialan Exp $
 */
public class SimpleArchiveUpload {
    //Create the logger
    private static final Logger logger = LoggerFactory.getLogger(SimpleArchiveUpload.class);

    public static void main(String[] args) {
        String yourAccessKeyId = TestConstants.ACCESS_ID;
        String yourAccessKeySecret = TestConstants.ACCESS_KEY;
        //初始化认证
        ServiceCredentials credentials = new ServiceCredentials(yourAccessKeyId,
            yourAccessKeySecret);
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "http://cn-hangzhou.oas.aliyuncs.com");

        // java sdk 会帮助用户完成 vaultName 到 vaultId 的转换
        // 由此避免了用户对一长串vaultId的记忆负担
        String yourVaultName = "oas_demo";
        File file = new File("oas_demo_data/data.bin");
        try {
            for (int i = 0; i < 1; i++) {
                UploadResult uploadResult = archiveManager.upload(yourVaultName, file);
                //archiveManager.uploadAsync(yourVaultName, file);
                logger.info("File {} uploaded complete. ArchiveId={},md5={},treeEtag={}",
                    file.getAbsolutePath(), uploadResult.getArchiveId(),
                    uploadResult.getContentEtag(), uploadResult.getTreeEtag());
            }

        } catch (OASClientException e) {
            logger.error("OASClientException Occured:", e);
        } catch (OASServerException e) {
            logger.error("OASServerException Occured:", e);
        } finally {
            //archiveManager.close();
        }

    }
}
