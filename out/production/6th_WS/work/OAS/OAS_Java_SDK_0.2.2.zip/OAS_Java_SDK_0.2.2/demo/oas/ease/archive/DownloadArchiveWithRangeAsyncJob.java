/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.ease.monitor.JobMonitor;
import com.aliyun.oas.model.common.Range;
import com.aliyun.oas.model.common.ServiceCredentials;
import com.aliyun.oas.utils.OASConstants;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: DownloadArchiveAsync.java, v 0.1 2015-5-27 上午11:18:07 jialan Exp $
 */
public class DownloadArchiveWithRangeAsyncJob {
    //Create the logger
    private static final Logger logger = LoggerFactory
        .getLogger(DownloadArchiveWithRangeAsyncJob.class);

    public static void main(String[] args) {

        String yourVaultName = "oas_demo";

        ServiceCredentials credentials = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "http://cn-hangzhou.oas.aliyuncs.com");
        String yourArchiveId = "";
        Range range = new Range(0, 128 * OASConstants.MEGABYTE - 1);//1MB
        //Range range = new Range(32 * OASConstants.MEGABYTES, 96 * OASConstants.MEGABYTES - 1);
        final JobMonitor jobMonitor = archiveManager
            .downloadWithRangeAsync(yourVaultName, yourArchiveId, range, "ttt")
            .withPeriodInSecond(3);

        // JobMonitor提供的阻塞等待方法，直到Job状态完结
        // 注意，本方法不建议用户使用，因为一个Job从提交到完成，一般需要几分钟到4个小时不等
        // 长期阻塞程序，不是一个明智的选择
        // 这里的使用仅仅起到示例作用
        jobMonitor.waitUntilFinished();

        /*
        final Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
        
            @Override
            public void run() {
                jobMonitor.refreshJobDescriptorFromRemote();
                if (jobMonitor.checkJobFinished()) {
                    timer.cancel();
                    synchronized (jobMonitor) {
                        jobMonitor.notify();
                    }
                }
                //System.out.println("Job's current status:" + jobMonitor.getJobStatus());
            }
        }, 0, 5000);
        
        synchronized (jobMonitor) {
            try {
                jobMonitor.wait();
            } catch (InterruptedException e) {
                logger.error("", e);
            }
        }
        */

        /*
        while (true) {
            if (jobMonitor.checkJobFinishedWithRefresh()) {
                System.out.println("Job has ended.");
                System.out.println("JobId=" + jobMonitor.getJobId() + ", JobStatus="
                                   + jobMonitor.getJobStatus() + ", TreeEtag="
                                   + jobMonitor.getDescriptor().getTreeEtag());
                break;
            } else {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    logger.error("ERROR!", e);
                }
            }
        }*/

        System.out.println("Job has succeeded.");
        System.out.println("JobId=" + jobMonitor.getJobId() + ", TreeEtag="
                           + jobMonitor.getDescriptor().getTreeEtag() + ", ArchiveTreeEtag="
                           + jobMonitor.getDescriptor().getArchiveTreeEtag());

    }
}
