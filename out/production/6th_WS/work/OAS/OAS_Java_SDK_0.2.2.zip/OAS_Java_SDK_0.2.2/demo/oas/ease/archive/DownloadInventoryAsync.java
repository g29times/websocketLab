/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.util.Timer;
import java.util.TimerTask;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aliyun.oas.TestConstants;
import com.aliyun.oas.OASFactory;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.ease.monitor.JobMonitor;
import com.aliyun.oas.model.common.ServiceCredentials;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: DownloadInventoryAsync.java, v 0.1 2015-6-3 下午2:58:59 jialan Exp $
 */
public class DownloadInventoryAsync {

    //Create the logger
    private static final Logger logger = LoggerFactory.getLogger(DownloadInventoryAsync.class);

    public static void main(String[] args) {
        ServiceCredentials credentials = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "http://cn-hangzhou.oas.aliyuncs.com");

        final JobMonitor jobMonitor = archiveManager.downloadInventoryAsync("oas_demo");

        final Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                if (jobMonitor.checkJobFinishedWithRefresh()) {
                    timer.cancel();
                    synchronized (jobMonitor) {
                        jobMonitor.notify();
                    }
                }
                //System.out.println("Job's current status:" + jobMonitor.getJobStatus());
            }
        }, 0, 5000);

        synchronized (jobMonitor) {
            try {
                jobMonitor.wait();
            } catch (InterruptedException e) {
                logger.error("", e);
            }
        }
        System.out.println("Job has ended.");
        System.out.println("JobId=" + jobMonitor.getJobId() + ", JobStatus="
                           + jobMonitor.getJobStatus() + ", TreeEtag="
                           + jobMonitor.getDescriptor().getTreeEtag());

    }
}
