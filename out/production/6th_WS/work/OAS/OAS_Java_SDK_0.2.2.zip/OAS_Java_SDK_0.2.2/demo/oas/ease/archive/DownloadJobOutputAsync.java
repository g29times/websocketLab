/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.io.File;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.ease.transfer.Transfer;
import com.aliyun.oas.model.common.ServiceCredentials;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: DownloadJobOutput.java, v 0.1 2015-5-28 上午10:39:35 jialan Exp $
 */
public class DownloadJobOutputAsync {
    public static void main(String[] args) {
        String yourVaultName = "oas_demo";
        String jobId = "";

        ServiceCredentials credentials = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "http://cn-hangzhou.oas.aliyuncs.com");

        Transfer<File> bt = archiveManager.downloadJobOutputAsync(yourVaultName, jobId,
            new File("oas_demo_data/out1.bin"));
        bt.waitUntilFinished();
    }
}
