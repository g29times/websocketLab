/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.util.Timer;
import java.util.TimerTask;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.ease.monitor.JobMonitor;
import com.aliyun.oas.model.common.ServiceCredentials;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: PushToOss.java, v 0.1 2015年9月17日 下午2:05:12 jialan Exp $
 */
public class PushToOss {
    public static void main(String[] args) {
        String yourAccessKeyId = TestConstants.ACCESS_ID;
        String yourAccessKeySecret = TestConstants.ACCESS_KEY;
        //初始化认证
        ServiceCredentials credentials = new ServiceCredentials(yourAccessKeyId,
            yourAccessKeySecret);
        // 通过工厂类获得archiveManager接口
        ArchiveManager archiveManager = OASFactory.archiveManagerFactory(credentials,
            "10.101.200.206");

        //        final JobMonitor jobMonitor = archiveManager.pullFromOssAsync("test",
        //            "oss-test.aliyun-inc.com", "oastest", "smallfile", "jialan test");
        final JobMonitor jobMonitor = archiveManager.pushToOssAsync("test",
            "A9F6A8FDA74250823512D85F41D4CAAA052BB8A6AC86414B8DAA651E83D0D3FBA4FC91965CCAE78EC1BA2D0411976A3EB29E26143041A550C0461036AF2CA484",
            "oss-test.aliyun-inc.com", "oastest", "jialanTestPush01", "jialan test push to oss");

        final Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                if (jobMonitor.checkJobFinishedWithRefresh()) {
                    timer.cancel();
                    synchronized (jobMonitor) {
                        jobMonitor.notify();
                    }
                }
                //System.out.println("Job's current status:" + jobMonitor.getJobStatus());
            }
        }, 0, 5000);

        synchronized (jobMonitor) {
            try {
                jobMonitor.wait();
            } catch (InterruptedException e) {
            }
        }
        System.out.println("Job has ended.");
        System.out
            .println("JobId=" + jobMonitor.getJobId() + ", JobStatus=" + jobMonitor.getJobStatus()
                     + ", archiveId=" + jobMonitor.getDescriptor().getArchiveId()
                     + ", archiveTreeEtag=" + jobMonitor.getDescriptor().getArchiveTreeEtag());
    }
}
