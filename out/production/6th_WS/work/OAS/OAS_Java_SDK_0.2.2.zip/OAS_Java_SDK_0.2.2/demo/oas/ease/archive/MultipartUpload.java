/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.io.File;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.ease.ArchiveManager;
import com.aliyun.oas.model.common.ServiceCredentials;

/**
 * 本Demo中的上传使用的是 ArchiveManager.upload 接口，
 * 本接口会根据用户文件大小自动为用户选择是否使用Multipart上传，
 * 判断的依据是，文件大鱼100MB，就采用Multipart上传。
 * @author jialan@alibaba-inc.com
 * @version $Id: TestMultipartUpload.java, v 0.1 2015-5-19 下午2:12:32 jialan Exp $
 */
public class MultipartUpload {
    public static void main(String[] args) {
        ServiceCredentials credentialsDebug = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        // 设置多线程并发数为5，默认：3，最大：10
        ArchiveManager manager = OASFactory
            .archiveManagerFactory(credentialsDebug, "http://cn-hangzhou.oas.aliyuncs.com")
            .withNumConcurrence(5).withMaxRetryTimePerRequest(-1);

        File file = new File("oas_demo_data/random196M.bin");

        // java sdk 会帮助用户完成 vaultName 到 vaultId 的转换
        // 由此避免了用户对一长串vaultId的记忆负担
        String myVaultName = TestConstants.VAULT_NAME;
        // 同一个upload接口，SDK会判断文件大小，超过100MB的自动为用户选取multipart上传方式
        String archiveId = manager.upload(myVaultName, file).getArchiveId();

        System.out.println("Archive ID=" + archiveId);
    }
}
