/**
 * Copyright (c) 2014 Alibaba Cloud Computing
 */
package oas.ease.archive;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.aliyun.oas.OASFactory;
import com.aliyun.oas.TestConstants;
import com.aliyun.oas.core.AliyunOASClient;
import com.aliyun.oas.model.common.ServiceCredentials;
import com.aliyun.oas.model.request.UploadArchiveRequest;
import com.aliyun.oas.model.result.UploadArchiveResult;
import com.aliyun.oas.utils.ContentEtagGenerator;
import com.aliyun.oas.utils.TreeEtagGenerator;

/**
 * 
 * @author jialan@alibaba-inc.com
 * @version $Id: StreamUpload.java, v 0.1 2015年7月14日 下午1:14:38 jialan Exp $
 */
public class StreamUpload {

    public static void main(String[] args) throws FileNotFoundException {
        String vaultId = ""; //TODO
        ServiceCredentials credentials = new ServiceCredentials(TestConstants.ACCESS_ID,
            TestConstants.ACCESS_KEY);
        String host = "http://cn-hangzhou.oas.aliyuncs.com";

        // 用OAS工厂获得AliyunOASClient对象

        AliyunOASClient aliyunOASClient = OASFactory.aliyunOASClientFactory(credentials, host)
            .withLogger();

        UploadArchiveRequest uploadRequest = new UploadArchiveRequest().withVaultId(vaultId);

        //byte[] data = "ksssssfffffffffffffffffffffffffffffffffffffffffssdssssssss".getBytes();

        File f = new File("oas_demo_data/random10M.bin");

        String contentEtag = new ContentEtagGenerator().update(f).asHex();
        String treeEtag = new TreeEtagGenerator().update(f).asHex();

        FileInputStream fi = new FileInputStream(f);

        uploadRequest.withStream(fi).withContentEtag(contentEtag).withTreeEtag(treeEtag);
        //uploadRequest.withStream(fi);
        uploadRequest.withFile(f);
        uploadRequest.withContentEtag(contentEtag).withTreeEtag(treeEtag);
        UploadArchiveResult uploadResult = aliyunOASClient.uploadArchive(uploadRequest);

        String archiveId = uploadResult.getArchiveId();
        System.out.println(archiveId);
    }

}
